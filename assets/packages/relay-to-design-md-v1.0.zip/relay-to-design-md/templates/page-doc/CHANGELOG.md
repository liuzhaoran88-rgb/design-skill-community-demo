---
file: CHANGELOG
slug: {{slug}}
bundle_part_of: design.md
bundle_role: changelog
last_updated: "{{today_iso}}"
---

# {{name_zh}} · 变更记录

> append-only：新条目加在最上方，旧条目不可删 / 改。每个 PR 一条。

| 时间 | 操作 | 来源 | 备注 |
|---|---|---|---|
| {{today_iso}} | 创建 | skill {{skill_version}} (page-doc bundle) | 自动生成 bundle / {{flag_count_note}} |
