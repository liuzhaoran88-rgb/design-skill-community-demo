# VENDOR NOTICE · ruler-annotation

> 本目录是 **vendored（并入）副本**，不是本仓原创 skill。

- **来源**：JD 同事的 `ruler-annotation-skill-v0.2.zip`（标尺打标 skill），2026-06-16 vendor 进本仓 `.claude/skills/`（commit `6c0f6da`）。原始作者为 JD 设计 / 研发同事（具体作者待补 / 见原 zip 元数据）。
- **为什么并进本仓**：本仓 skill `relay-spec-longpage` 的 **§03「基础结构&设计属性」标注**（结构示意 = 内容标注、设计属性尺寸/间距 = 双色结构标注）委托本 skill；`relay-to-component-pipeline` 的 **Phase 3** 经由 `relay-spec-longpage` 间接依赖。为让该管线**自包含、可随仓库分发**（别人 clone 仓库即可跑全流程），把副本 vendor 进来。
- **独立分发**：本 skill **不依赖外部 `.claude/shared/` 文件**，整目录（`SKILL.md` + `references/` + `evals/` + `README.md`）可独立拷贝，不受本仓路径中立化约定影响。
- **⚠️ 漂移风险**：这是一份副本，会与同事上游 / 全局 `~/.claude/skills/` 版本**各自漂移**。三处（同事上游 / 全局 / 本仓）不自动同步。
- **版本 / 本仓演进**：源 zip 为 **v0.2**；本仓副本已演进到 **v0.3**（新增结构标注「盒模型色块模式 B」+ 拆分「内容标注 / 结构标注」两类 + §03 与 `relay-spec-longpage` 耦合）。逐版差异见本目录 `README.md`「版本」段与 `git log`；哪些 delta 属上游、哪些属本仓增补待与原作者对齐。
- **维护约定**：在本副本上的改动**建议回流同事上游 + 同步全局副本**，避免三处长期漂移；重大改动先与原作者对齐。与 [[ref_relay_component_skills]] 的 vendored skill（`relay-component-set-architect` / `-variant-generator`）同款约定。

相关：依赖方 [`../relay-spec-longpage/SKILL.md`](../relay-spec-longpage/SKILL.md) §03 标注 · [`../relay-to-component-pipeline/SKILL.md`](../relay-to-component-pipeline/SKILL.md) Phase 3。
